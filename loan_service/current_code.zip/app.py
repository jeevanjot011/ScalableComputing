cd ~/environment/scalable/loan_service

cat > app.py << 'EOF'
import json
import math
import boto3
import os
import logging
from datetime import datetime
from decimal import Decimal

# Setup logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')
sqs = boto3.client('sqs')

# Get environment variables
TABLE_NAME = os.environ.get('TABLE_NAME', 'ScalableG1')
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN', '')
SQS_QUEUE_URL = os.environ.get('SQS_QUEUE_URL', '')

def calculate_loan_emi(principal, annual_rate, years):
    monthly_rate = annual_rate / (12 * 100)
    months = years * 12
    if monthly_rate == 0:
        emi = principal / months
    else:
        emi = principal * monthly_rate * (1 + monthly_rate)**months / ((1 + monthly_rate)**months - 1)
    total_payment = emi * months
    total_interest = total_payment - principal
    
    # Convert to Decimal for DynamoDB compatibility
    return {
        "emi": Decimal(str(round(emi, 2))),
        "total_payment": Decimal(str(round(total_payment, 2))),
        "total_interest": Decimal(str(round(total_interest, 2))),
        "months": months  # Integer is fine
    }

def convert_to_decimal(obj):
    """Recursively convert floats to Decimals for DynamoDB"""
    if isinstance(obj, float):
        return Decimal(str(obj))
    elif isinstance(obj, dict):
        return {k: convert_to_decimal(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_to_decimal(v) for v in obj]
    return obj

def save_to_dynamodb(calculation_id, data):
    """Save calculation result to DynamoDB"""
    try:
        logger.info(f"Saving to DynamoDB: {calculation_id}")
        
        table = dynamodb.Table(TABLE_NAME)
        
        # Build item with Decimal types
        item = {
            'order_id': calculation_id,
            'timestamp': datetime.now().isoformat(),
            'type': 'loan_calculation',
            'principal': Decimal(str(data['input']['principal'])),
            'annual_rate': Decimal(str(data['input']['annual_rate'])),
            'years': data['input']['years'],  # Integer
            'emi': data['emi'],  # Already Decimal
            'total_payment': data['total_payment'],  # Already Decimal
            'total_interest': data['total_interest'],  # Already Decimal
            'ttl': int((datetime.now().timestamp() + 90 * 24 * 60 * 60))
        }
        
        # Convert any remaining floats to Decimal
        item = convert_to_decimal(item)
        
        logger.info(f"Item to save: {json.dumps({k: str(v) for k, v in item.items()})}")
        
        response = table.put_item(Item=item)
        logger.info(f"DynamoDB save successful: {response}")
        return True
        
    except Exception as e:
        logger.error(f"DynamoDB error: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return False

def send_sns_notification(calculation_id, data):
    """Send SNS notification for large loans"""
    try:
        if SNS_TOPIC_ARN and float(data['input']['principal']) > 1000000:
            logger.info(f"Sending SNS for large loan: {data['input']['principal']}")
            
            # Convert Decimals to strings for SNS message
            message = f"Large loan calculation: ₹{data['input']['principal']}\n"
            message += f"EMI: ₹{float(data['emi']):.2f}/month for {data['input']['years']} years\n"
            message += f"Calculation ID: {calculation_id}"
            
            sns.publish(
                TopicArn=SNS_TOPIC_ARN,
                Subject=f"High Value Loan Alert - {calculation_id}",
                Message=message
            )
            logger.info("SNS sent successfully")
        return True
    except Exception as e:
        logger.error(f"SNS error: {str(e)}")
        return False

def send_to_sqs(calculation_id, data):
    """Send to SQS for async processing"""
    try:
        if SQS_QUEUE_URL:
            logger.info(f"Sending to SQS: {calculation_id}")
            
            # Convert Decimals to floats for JSON serialization
            message_data = {
                'calculation_id': calculation_id,
                'type': 'loan_calculation',
                'timestamp': datetime.now().isoformat(),
                'data': {
                    'emi': float(data['emi']),
                    'total_payment': float(data['total_payment']),
                    'total_interest': float(data['total_interest']),
                    'input': {
                        'principal': float(data['input']['principal']),
                        'annual_rate': float(data['input']['annual_rate']),
                        'years': data['input']['years']
                    }
                }
            }
            
            sqs.send_message(
                QueueUrl=SQS_QUEUE_URL,
                MessageBody=json.dumps(message_data)
            )
            logger.info("SQS sent successfully")
        return True
    except Exception as e:
        logger.error(f"SQS error: {str(e)}")
        return False

def lambda_handler(event, context):
    request_id = context.aws_request_id if context else 'unknown'
    logger.info(f"Request: {request_id}")
    
    try:
        http_method = event.get('httpMethod', 'POST')
        
        # Health check
        if http_method == 'GET':
            db_status = "unknown"
            try:
                table = dynamodb.Table(TABLE_NAME)
                table.table_status
                db_status = "connected"
            except Exception as e:
                db_status = f"error: {str(e)}"
            
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'status': 'healthy',
                    'service': 'loan-calculator',
                    'version': '2.1.0',
                    'request_id': request_id,
                    'dynamodb': db_status,
                    'features': {
                        'calculation': True,
                        'persistence': TABLE_NAME != '',
                        'notifications': SNS_TOPIC_ARN != '',
                        'queue': SQS_QUEUE_URL != ''
                    }
                })
            }
        
        # Parse input
        body_str = event.get('body') if event.get('body') else '{}'
        if isinstance(body_str, str):
            body = json.loads(body_str)
        else:
            body = body_str
        
        principal = float(body.get('principal', 0))
        annual_rate = float(body.get('annual_rate', 0))
        years = int(body.get('years', 0))
        
        # Validation
        if principal <= 0 or annual_rate < 0 or years <= 0:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': 'Invalid input. All values must be positive.',
                    'request_id': request_id
                })
            }
        
        # Calculate (returns Decimals)
        result = calculate_loan_emi(principal, annual_rate, years)
        result['input'] = {
            'principal': principal,
            'annual_rate': annual_rate,
            'years': years
        }
        result['request_id'] = request_id
        
        # Async operations
        result['persisted'] = save_to_dynamodb(request_id, result)
        result['notification_sent'] = send_sns_notification(request_id, result)
        result['queued'] = send_to_sqs(request_id, result)
        
        # Convert Decimals to floats for JSON response
        response_result = {
            'emi': float(result['emi']),
            'total_payment': float(result['total_payment']),
            'total_interest': float(result['total_interest']),
            'months': result['months'],
            'input': result['input'],
            'request_id': request_id,
            'persisted': result['persisted'],
            'notification_sent': result['notification_sent'],
            'queued': result['queued']
        }
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(response_result, indent=2)
        }
        
    except json.JSONDecodeError as e:
        return {
            'statusCode': 400,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({'error': 'Invalid JSON', 'request_id': request_id})
        }
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        import traceback
        logger.error(f"Traceback: {traceback.format_exc()}")
        return {
            'statusCode': 500